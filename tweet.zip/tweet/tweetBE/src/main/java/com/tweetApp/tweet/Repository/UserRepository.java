package com.tweetApp.tweet.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetApp.tweet.Model.Register;

public interface UserRepository extends MongoRepository<Register,Integer> {
	
	Register findByemail(String email);
	
	Register findById(int id);
	

}
