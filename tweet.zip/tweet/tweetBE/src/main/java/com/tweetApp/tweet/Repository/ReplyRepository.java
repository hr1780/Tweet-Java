package com.tweetApp.tweet.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetApp.tweet.Model.Reply;

public interface ReplyRepository extends MongoRepository<Reply,String> {
	
	List<Reply> findByTweetId(int tweetId);

}
